
let forms = [];
let currentEditingForm = null;
let formsItemCounter = 0;
let signatureItemCounter = 0;
let confirmCallback = null;
let draggedElement = null;
let draggedIndex = null;

document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    
    const confirmOkBtn = document.getElementById('confirmOkBtn');
    if (confirmOkBtn) {
        confirmOkBtn.addEventListener('click', function() {
            if (confirmCallback) {
                confirmCallback();
                confirmCallback = null;
            }
            closeConfirmModal();
        });
    }
    
    const loginPassword = document.getElementById('loginPassword');
    if (loginPassword) {
        loginPassword.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                checkLogin();
            }
        });
    }
});

function checkAuth() {
    const isAuthenticated = localStorage.getItem('adminAuth') === 'true';
    if (!isAuthenticated) {
        document.getElementById('loginModal').style.display = 'block';
        document.getElementById('adminPanel').style.display = 'none';
        document.getElementById('formsList').style.display = 'none';
    } else {
        document.getElementById('loginModal').style.display = 'none';
        loadForms();
    }
}

function checkLogin() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    if (username === 'admin' && password === '22959899') {
        localStorage.setItem('adminAuth', 'true');
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
        document.getElementById('formsList').style.display = 'block';
        loadForms();
    } else {
        showAlert('帳號或密碼錯誤', 'error');
    }
}

function showConfirmModal(message, callback) {
    const messageEl = document.getElementById('confirmMessage');
    if (messageEl) {
        messageEl.textContent = message;
    }
    confirmCallback = callback;
    document.getElementById('confirmModal').style.display = 'block';
}

function closeConfirmModal() {
    document.getElementById('confirmModal').style.display = 'none';
    confirmCallback = null;
}

function handleDragStart(e) {
    draggedElement = this;
    draggedIndex = Array.from(this.parentNode.children).indexOf(this);
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragOver(e) {
    if (this === draggedElement) return;
    
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    
    const afterElement = getDragAfterElement(this.parentNode, e.clientY);
    const children = [...this.parentNode.children];
    
    if (afterElement == null || afterElement === draggedElement) {
        this.parentNode.appendChild(draggedElement);
    } else {
        const draggedIndex = children.indexOf(draggedElement);
        const afterIndex = children.indexOf(afterElement);
        
        if (draggedIndex < afterIndex) {
            this.parentNode.insertBefore(draggedElement, afterElement.nextSibling);
        } else {
            this.parentNode.insertBefore(draggedElement, afterElement);
        }
    }
}

function handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    this.classList.remove('drag-over');
    return false;
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
    document.querySelectorAll('.form-item').forEach(item => {
        item.classList.remove('drag-over');
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.form-item:not(.dragging)')];
    
    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function loadForms() {
    const saved = localStorage.getItem('forms');
    if (saved) {
        forms = JSON.parse(saved);
        displayForms();
    }
}

function displayForms() {
    const container = document.getElementById('formsContainer');
    container.innerHTML = '';

    if (forms.length === 0) {
        container.innerHTML = '<p style="text-align:center; color:#666;">尚未建立任何申請表</p>';
        return;
    }

    forms.forEach((form, index) => {
        const formCard = document.createElement('div');
        formCard.className = 'form-card';
        
        const fillUrl = `${window.location.origin}${window.location.pathname.replace('index.html', 'form-fill.html')}?id=${index}`;
        
        formCard.innerHTML = `
            <h3>${form.name}</h3>
            <p style="margin-bottom: 25px;">${form.items.length} 個欄位</p>
            
            <div style="margin-bottom: 25px;">
                <label style="font-size: 12px; color: #666; letter-spacing: 0.5px; display: block; margin-bottom: 8px;">試算表 ID</label>
                <input type="text" id="spreadsheetId-${index}" value="${form.spreadsheetId || ''}" placeholder="選填" style="width: 100%; padding: 8px 0; border: none; border-bottom: 1px solid #ddd; font-size: 14px; background: transparent;">
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="font-size: 12px; color: #666; letter-spacing: 0.5px; display: block; margin-bottom: 8px;">Apps Script URL</label>
                <input type="text" id="appsScriptUrl-${index}" value="${form.appsScriptUrl || ''}" placeholder="選填" style="width: 100%; padding: 8px 0; border: none; border-bottom: 1px solid #ddd; font-size: 13px; background: transparent;">
                <div style="display: flex; gap: 8px; margin-top: 12px;">
                    <button class="btn btn-sm btn-success" onclick="saveFormSettings(${index})">儲存</button>
                    <button class="btn btn-sm btn-secondary" onclick="showGoogleScriptCode(${index})">代碼</button>
                </div>
            </div>
            
            <div style="display: flex; gap: 8px;">
                <button class="btn btn-sm btn-primary" onclick="window.open('${fillUrl}', '_blank')" style="flex: 1;">預覽</button>
                <button class="btn btn-sm btn-secondary" onclick="editForm(${index})" style="flex: 1;">編輯</button>
                <button class="btn btn-sm btn-danger" onclick="deleteForm(${index})" style="flex: 1;">刪除</button>
            </div>
            
            <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid #e8e8e8;">
                <button class="btn btn-sm btn-success" onclick="generateStandaloneFile(${index})" style="width: 100%;">生成獨立檔案</button>
            </div>
        `;
        container.appendChild(formCard);
    });
}

function addFormItem() {
    document.getElementById('itemModal').style.display = 'block';
    document.getElementById('optionsGroup').style.display = 'none';
}

function closeModal() {
    document.getElementById('itemModal').style.display = 'none';
    resetItemForm();
}

function resetItemForm() {
    document.getElementById('fieldType').value = 'text';
    document.getElementById('fieldLabel').value = '';
    document.getElementById('fieldName').value = '';
    document.getElementById('fieldOptions').value = '';
    document.getElementById('fieldRequired').value = 'true';
}

function addSignatureItem() {
    document.getElementById('signatureModal').style.display = 'block';
}

function closeSignatureModal() {
    document.getElementById('signatureModal').style.display = 'none';
    document.getElementById('signatureLabel').value = '';
}

function confirmAddSignatureItem() {
    const label = document.getElementById('signatureLabel').value;

    if (!label) {
        showAlert('請填寫名稱', 'error');
        return;
    }

    const signatureItem = {
        id: signatureItemCounter++,
        label: label
    };

    addSignatureItemToForm(signatureItem);
    closeSignatureModal();
}

function addSignatureItemToForm(signatureItem) {
    const container = document.getElementById('signatureItems');
    
    const itemDiv = document.createElement('div');
    itemDiv.className = 'form-item';
    itemDiv.dataset.id = signatureItem.id;
    itemDiv.dataset.itemData = JSON.stringify(signatureItem);
    
    itemDiv.innerHTML = `
        <div class="form-item-header">
            <span class="form-item-title">${signatureItem.label}</span>
            <div class="form-item-controls">
                <button class="btn btn-sm btn-danger" onclick="removeSignatureItem(${signatureItem.id})">刪除</button>
            </div>
        </div>
    `;
    
    itemDiv.draggable = true;
    itemDiv.addEventListener('dragstart', handleDragStart);
    itemDiv.addEventListener('dragover', handleDragOver);
    itemDiv.addEventListener('drop', handleDrop);
    itemDiv.addEventListener('dragend', handleDragEnd);
    
    container.appendChild(itemDiv);
}

function removeSignatureItem(id) {
    const item = document.querySelector(`[data-id="${id}"]`);
    if (item) {
        item.remove();
    }
}

document.getElementById('fieldType').addEventListener('change', function() {
    const type = this.value;
    const optionsGroup = document.getElementById('optionsGroup');
    
    if (type === 'select' || type === 'radio' || type === 'checkbox' || type === 'selecttext') {
        optionsGroup.style.display = 'block';
    } else {
        optionsGroup.style.display = 'none';
    }
});

function confirmAddItem() {
    const type = document.getElementById('fieldType').value;
    const label = document.getElementById('fieldLabel').value;
    const name = document.getElementById('fieldName').value;
    const required = document.getElementById('fieldRequired').value === 'true';
    const options = document.getElementById('fieldOptions').value;

    if (!label || !name) {
        showAlert('請填寫完整', 'error');
        return;
    }

    const item = {
        id: formsItemCounter++,
        type: type,
        label: label,
        name: name,
        required: required
    };

    if (options && (type === 'select' || type === 'radio' || type === 'checkbox' || type === 'selecttext')) {
        item.options = options.split(',').map(opt => opt.trim());
    }

    addItemToForm(item);
    closeModal();
}

function addItemToForm(item) {
    const container = document.getElementById('formItems');
    
    const itemDiv = document.createElement('div');
    itemDiv.className = 'form-item';
    itemDiv.dataset.id = item.id;
    
    itemDiv.dataset.itemData = JSON.stringify(item);
    
    let optionsText = '';
    if (item.options) {
        optionsText = `（選項：${item.options.join('、')}）`;
    }

    itemDiv.innerHTML = `
        <div class="form-item-header">
            <span class="form-item-title">${item.label} [${item.type}]${optionsText}</span>
            <div class="form-item-controls">
                <button class="btn btn-sm btn-danger" onclick="removeFormItem(${item.id})">刪除</button>
            </div>
        </div>
    `;
    
    itemDiv.draggable = true;
    itemDiv.addEventListener('dragstart', handleDragStart);
    itemDiv.addEventListener('dragover', handleDragOver);
    itemDiv.addEventListener('drop', handleDrop);
    itemDiv.addEventListener('dragend', handleDragEnd);
    
    container.appendChild(itemDiv);
    resetItemForm();
}

function removeFormItem(id) {
    const item = document.querySelector(`[data-id="${id}"]`);
    if (item) {
        item.remove();
    }
}

function saveForm() {
    const name = document.getElementById('formName').value;
    const spreadsheetId = document.getElementById('spreadsheetId').value;

    const formItems = document.querySelectorAll('#formItems .form-item');
    if (formItems.length === 0) {
        showAlert('請新增欄位', 'error');
        return;
    }

    if (!name) {
        showAlert('請輸入名稱', 'error');
        return;
    }

    const items = Array.from(formItems).map(item => {
        const itemData = JSON.parse(item.dataset.itemData);
        delete itemData.id;
        return itemData;
    });

    const signatureItems = document.querySelectorAll('#signatureItems .form-item');
    const signatures = Array.from(signatureItems).map(item => {
        const itemData = JSON.parse(item.dataset.itemData);
        delete itemData.id;
        return itemData;
    });

    const formData = {
        name: name,
        spreadsheetId: spreadsheetId,
        appsScriptUrl: '',
        items: items,
        signatures: signatures || []
    };

    if (currentEditingForm !== null) {
        formData.appsScriptUrl = forms[currentEditingForm].appsScriptUrl || '';
        forms[currentEditingForm] = formData;
        currentEditingForm = null;
    } else {
        forms.push(formData);
    }

    localStorage.setItem('forms', JSON.stringify(forms));
    
    document.getElementById('formName').value = '';
    document.getElementById('spreadsheetId').value = '';
    document.getElementById('formItems').innerHTML = '';
    document.getElementById('signatureItems').innerHTML = '';
    formsItemCounter = 0;
    signatureItemCounter = 0;

    showAlert('已儲存', 'success');
    displayForms();
}

function editForm(index) {
    const form = forms[index];
    
    document.getElementById('formName').value = form.name;
    document.getElementById('spreadsheetId').value = form.spreadsheetId || '';
    
    document.getElementById('formItems').innerHTML = '';
    document.getElementById('signatureItems').innerHTML = '';
    formsItemCounter = 0;
    signatureItemCounter = 0;
    
    form.items.forEach(item => {
        addItemToForm({
            id: formsItemCounter++,
            ...item
        });
    });
    
    if (form.signatures && form.signatures.length > 0) {
        form.signatures.forEach(sig => {
            addSignatureItemToForm({
                id: signatureItemCounter++,
                ...sig
            });
        });
    }
    
    currentEditingForm = index;
    window.scrollTo(0, 0);
}

function deleteForm(index) {
    showConfirmModal('確定要刪除此申請表嗎？', function() {
        forms.splice(index, 1);
        localStorage.setItem('forms', JSON.stringify(forms));
        displayForms();
        showAlert('已刪除', 'success');
    });
}

function saveFormSettings(index) {
    try {
        const spreadsheetId = document.getElementById(`spreadsheetId-${index}`).value;
        const appsScriptUrl = document.getElementById(`appsScriptUrl-${index}`).value;
        
        forms[index].spreadsheetId = spreadsheetId;
        forms[index].appsScriptUrl = appsScriptUrl;
        
        localStorage.setItem('forms', JSON.stringify(forms));
        
        showAlert('已儲存', 'success');
    } catch (error) {
        showAlert('儲存失敗', 'error');
        console.error('儲存錯誤：', error);
    }
}


function showAlert(message, type) {
    const oldToast = document.querySelector('.toast');
    if (oldToast) {
        oldToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = 'toast' + (type === 'error' ? ' error' : '');
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 300);
    }, 3000);
}

function copyLink(url) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(function() {
            showAlert('已複製', 'success');
        }, function(err) {
            console.error('無法複製：', err);
            showAlert('複製失敗', 'error');
        });
    } else {
        const textArea = document.createElement('textarea');
        textArea.value = url;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            showAlert('已複製', 'success');
        } catch (err) {
            showAlert('複製失敗', 'error');
        }
        document.body.removeChild(textArea);
    }
}

function showGoogleScriptCode(index) {
    const form = forms[index];
    const spreadsheetId = form.spreadsheetId || 'YOUR_SPREADSHEET_ID_HERE';
    
    const code = `function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const spreadsheetId = data.spreadsheetId;
    const rowData = data.rowData;
    const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
    let sheet = spreadsheet.getActiveSheet();
    const lastRow = sheet.getLastRow();
    const headers = Object.keys(rowData);
    
    if (lastRow === 0) {
      sheet.appendRow(headers);
    } else {
      const existingHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
      const newHeaders = headers.filter(h => !existingHeaders.includes(h));
      if (newHeaders.length > 0) {
        sheet.getRange(1, existingHeaders.length + 1, 1, newHeaders.length).setValues([newHeaders]);
      }
    }
    
    const allHeaders = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    const orderedData = allHeaders.map(header => rowData[header] || '');
    sheet.appendRow(orderedData);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: '資料已成功儲存'
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  return ContentService.createTextOutput('Google Sheets Integration is working!').setMimeType(ContentService.MimeType.TEXT);
}`;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(code).then(function() {
            showAlert('代碼已複製', 'success');
        }, function(err) {
            console.error('無法複製：', err);
            showAlert('複製失敗', 'error');
        });
    } else {
        const textArea = document.createElement('textarea');
        textArea.value = code;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            showAlert('代碼已複製', 'success');
        } catch (err) {
            showAlert('複製失敗', 'error');
        }
        document.body.removeChild(textArea);
    }
}

function generateStandaloneFile(index) {
    const form = forms[index];
    
    try {
        let template = `<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORM_TITLE</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft JhengHei', '微軟正黑體', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            background: #fafafa;
            color: #1a1a1a;
            line-height: 1.6;
            font-weight: 400;
            min-height: 100vh;
            padding: 60px 20px;
        }

        .container {
            max-width: 700px;
            margin: 0 auto;
        }

        .card {
            background: #fff;
            border: 1px solid #e8e8e8;
            padding: 60px 50px;
        }

        .logo {
            display: none;
            text-align: center;
            margin-bottom: 30px;
        }

        .logo img {
            max-height: 80px;
            max-width: 100%;
        }

        h2 {
            font-size: 28px;
            font-weight: 500;
            color: #000;
            margin-bottom: 50px;
            letter-spacing: 1px;
        }

        .btn {
            padding: 16px 50px;
            border: 1px solid #000;
            background: #000;
            color: #fff;
            font-size: 16px;
            font-weight: 500;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.2s ease;
            text-transform: uppercase;
            margin-right: 10px;
        }

        .btn:hover {
            background: #333;
        }

        .btn-secondary {
            background: #fff;
            color: #888;
            border-color: #ccc;
        }

        .btn-secondary:hover {
            background: #f5f5f5;
            color: #000;
        }

        .form-group {
            margin-bottom: 40px;
        }

        label {
            display: block;
            margin-bottom: 12px;
            font-weight: 500;
            color: #333;
            font-size: 16px;
            letter-spacing: 0.5px;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 18px;
            transition: border-color 0.3s;
            background: #fff;
            color: #000;
        }

        input:focus,
        textarea:focus,
        select:focus {
            outline: none;
            border-color: #000;
            box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1);
        }

        textarea {
            min-height: 120px;
            resize: vertical;
            border: 1px solid #e8e8e8;
            padding: 12px;
        }

        textarea:focus {
            border-color: #000;
            box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1);
        }

        input::placeholder,
        textarea::placeholder {
            color: #999;
        }

        .checkbox-group, .radio-group {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .checkbox-group label, .radio-group label {
            font-weight: 500;
            display: flex;
            align-items: center;
            cursor: pointer;
            font-size: 16px;
        }

        .checkbox-group input, .radio-group input {
            width: 20px;
            height: 20px;
            margin-right: 12px;
        }

        .toast {
            position: fixed;
            top: 40px;
            left: 50%;
            transform: translateX(-50%);
            background: #000;
            color: #fff;
            padding: 15px 30px;
            font-size: 13px;
            letter-spacing: 1px;
            z-index: 2000;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .toast.show {
            opacity: 1;
        }

        .toast.error {
            background: #ff4444;
        }

        .required {
            color: #ff4444;
        }

        .form-actions {
            text-align: left;
            margin-top: 60px;
            padding-top: 40px;
            border-top: 1px solid #e8e8e8;
        }

        @media (max-width: 768px) {
            .card {
                padding: 40px 30px;
            }

            body {
                padding: 30px 15px;
            }

            h2 {
                font-size: 20px;
                margin-bottom: 40px;
            }

            .form-actions {
                margin-top: 40px;
            }
        }

        @media print {
            body {
                background: #fff;
                padding: 0;
                font-size: 12pt;
                min-height: auto;
                font-family: 'BiauKai', 'KaiTi', 'DFKai-SB', serif !important;
            }

            .alert,
            .btn,
            .form-actions,
            .toast {
                display: none !important;
            }

            .logo {
                display: block !important;
            }

            .container {
                max-width: 100%;
            }

            .card {
                border: none;
                padding: 0;
                box-shadow: none;
                background: #fff !important;
            }

            h2 {
                font-size: 24pt;
                margin: 30pt 0 25pt 0;
                font-weight: 500;
                border-bottom: 2pt solid #000;
                padding-bottom: 10pt;
                text-align: center;
                letter-spacing: 2pt;
            }

            .form-group {
                margin-bottom: 18pt;
                page-break-inside: avoid;
                display: flex;
                flex-wrap: wrap;
                align-items: baseline;
            }

            label {
                font-weight: 500;
                font-size: 11pt;
                margin-right: 8pt;
                margin-bottom: 3pt;
                width: auto;
                min-width: 80pt;
            }

            .required {
                display: none !important;
            }

            input[type="text"],
            input[type="email"],
            input[type="number"],
            input[type="date"],
            textarea,
            select {
                border: none !important;
                border-bottom: none !important;
                padding: 4pt 0;
                font-size: 12pt;
                background: transparent !important;
                outline: none !important;
                flex: 1;
                min-width: 150pt;
                box-shadow: none !important;
            }

            select {
                appearance: none;
                -webkit-appearance: none;
                background-image: none;
            }

            textarea {
                border: none !important;
                padding: 8pt 0;
                min-height: 80pt;
                width: 100%;
                resize: none;
                box-shadow: none !important;
            }

            .checkbox-group,
            .radio-group {
                margin-top: 0;
                width: 100%;
                margin-left: 88pt;
            }

            .checkbox-group label,
            .radio-group label {
                margin-bottom: 6pt;
                display: block !important;
                font-weight: 400;
                width: auto;
                min-width: auto;
                position: relative;
            }

            input[type="checkbox"],
            input[type="radio"] {
                width: 14pt;
                height: 14pt;
                margin-right: 6pt;
                margin-left: 0;
                vertical-align: middle;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .selecttext-group {
                display: flex !important;
                gap: 0 !important;
                flex: 1 !important;
                flex-wrap: nowrap !important;
                min-width: 0 !important;
            }

            .selecttext-group select {
                flex: 0 0 50pt !important;
                width: 50pt !important;
                max-width: 50pt !important;
                min-width: 0 !important;
                margin-right: 5pt !important;
            }

            .selecttext-group input {
                flex: 1 !important;
                min-width: 0 !important;
            }

            .signature-section {
                display: block !important;
                margin-top: 30pt;
                padding-top: 15pt;
                border-top: 1pt solid #000;
            }

            .signature-line {
                display: inline-block;
                width: 150pt;
                border-bottom: 1pt solid #000;
                margin: 0 15pt;
                height: 30pt;
                vertical-align: bottom;
            }

            .signature-section strong {
                font-weight: 500;
                font-size: 11pt;
                margin-right: 10pt;
            }

            @page {
                margin: 20mm 15mm;
                size: A4;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">
                <img src="logo.png" alt="Logo">
            </div>
            <h2 id="formTitle">FORM_TITLE</h2>
            <form id="userForm">
                <div id="formFields"></div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">提交</button>
                    <button type="reset" class="btn btn-secondary">清除</button>
                </div>
            </form>
        </div>
    </div>
SCRIPT_CONTENT
</body>
</html>`;
        
        const formDataScript = `
        const formData = ${JSON.stringify(form, null, 8)};
        
        function loadForm() {
            document.getElementById('formTitle').textContent = formData.name;
            const container = document.getElementById('formFields');
            
            formData.items.forEach(item => {
                const div = document.createElement('div');
                div.className = 'form-group';

                const label = document.createElement('label');
                label.innerHTML = item.label + (item.required ? '<span class="required"> *</span>' : '');
                div.appendChild(label);

                let input;
                switch(item.type) {
                    case 'textarea':
                        input = document.createElement('textarea');
                        input.name = item.name;
                        if (item.required) input.required = true;
                        div.appendChild(input);
                        break;

                    case 'select':
                        input = document.createElement('select');
                        input.name = item.name;
                        if (item.required) input.required = true;
                        
                        const defaultOption = document.createElement('option');
                        defaultOption.value = '';
                        defaultOption.textContent = '選擇';
                        input.appendChild(defaultOption);
                        
                        if (item.options) {
                            item.options.forEach(opt => {
                                const option = document.createElement('option');
                                option.value = opt;
                                option.textContent = opt;
                                input.appendChild(option);
                            });
                        }
                        div.appendChild(input);
                        break;

                    case 'selecttext':
                        const selectGroup = document.createElement('div');
                        selectGroup.className = 'selecttext-group';
                        selectGroup.style.display = 'flex';
                        selectGroup.style.gap = '15px';
                        selectGroup.style.alignItems = 'center';
                        
                        const selectInput = document.createElement('select');
                        selectInput.id = item.name + '_select';
                        selectInput.name = item.name + '_select';
                        selectInput.style.flex = '0 0 150px';
                        if (item.required) selectInput.required = true;
                        
                        const defaultOpt = document.createElement('option');
                        defaultOpt.value = '';
                        defaultOpt.textContent = '選擇類別';
                        selectInput.appendChild(defaultOpt);
                        
                        if (item.options) {
                            item.options.forEach(opt => {
                                const option = document.createElement('option');
                                option.value = opt;
                                option.textContent = opt;
                                selectInput.appendChild(option);
                            });
                        }
                        
                        const textInput = document.createElement('input');
                        textInput.type = 'text';
                        textInput.name = item.name + '_text';
                        textInput.id = item.name + '_text';
                        textInput.placeholder = '請先選擇類別';
                        textInput.style.flex = '1';
                        textInput.disabled = true;
                        
                        selectInput.addEventListener('change', function() {
                            if (this.value) {
                                textInput.disabled = false;
                                textInput.placeholder = '請輸入' + this.value + '的名稱';
                                if (item.required) textInput.required = true;
                            } else {
                                textInput.disabled = true;
                                textInput.value = '';
                                textInput.placeholder = '請先選擇類別';
                                textInput.required = false;
                            }
                        });
                        
                        selectGroup.appendChild(selectInput);
                        selectGroup.appendChild(textInput);
                        div.appendChild(selectGroup);
                        break;

                    case 'radio':
                        const radioGroup = document.createElement('div');
                        radioGroup.className = 'radio-group';
                        if (item.options) {
                            item.options.forEach((opt, idx) => {
                                const radioDiv = document.createElement('label');
                                const radio = document.createElement('input');
                                radio.type = 'radio';
                                radio.name = item.name;
                                radio.value = opt;
                                if (item.required) radio.required = true;
                                
                                radioDiv.appendChild(radio);
                                radioDiv.appendChild(document.createTextNode(opt));
                                radioGroup.appendChild(radioDiv);
                            });
                        }
                        div.appendChild(radioGroup);
                        break;

                    case 'checkbox':
                        const checkboxGroup = document.createElement('div');
                        checkboxGroup.className = 'checkbox-group';
                        if (item.options) {
                            item.options.forEach(opt => {
                                const checkboxDiv = document.createElement('label');
                                const checkbox = document.createElement('input');
                                checkbox.type = 'checkbox';
                                checkbox.name = item.name;
                                checkbox.value = opt;
                                
                                checkboxDiv.appendChild(checkbox);
                                checkboxDiv.appendChild(document.createTextNode(opt));
                                checkboxGroup.appendChild(checkboxDiv);
                            });
                        }
                        div.appendChild(checkboxGroup);
                        break;

                    case 'date':
                        input = document.createElement('input');
                        input.type = 'date';
                        input.name = item.name;
                        if (item.required) input.required = true;
                        div.appendChild(input);
                        break;

                    case 'email':
                        input = document.createElement('input');
                        input.type = 'email';
                        input.name = item.name;
                        if (item.required) input.required = true;
                        div.appendChild(input);
                        break;

                    case 'number':
                        input = document.createElement('input');
                        input.type = 'number';
                        input.name = item.name;
                        if (item.required) input.required = true;
                        div.appendChild(input);
                        break;

                    default:
                        input = document.createElement('input');
                        input.type = 'text';
                        input.name = item.name;
                        if (item.required) input.required = true;
                        div.appendChild(input);
                }

                container.appendChild(div);
            });
            
            if (formData.signatures && formData.signatures.length > 0) {
                const signatureDiv = document.createElement('div');
                signatureDiv.className = 'signature-section';
                signatureDiv.style.display = 'none';
                
                let signatureHTML = '';
                formData.signatures.forEach(sig => {
                    signatureHTML += \`
                        <div style="margin-bottom: 30px;">
                            <strong>\${sig.label}：</strong>
                            <span class="signature-line"></span>
                        </div>
                    \`;
                });
                
                signatureDiv.innerHTML = signatureHTML;
                container.appendChild(signatureDiv);
            }
        }

        document.getElementById('userForm').addEventListener('submit', function(e) {
            e.preventDefault();
            submitForm();
        });

        function submitForm() {
            const formElement = document.getElementById('userForm');
            const formData_obj = new FormData(formElement);
            
            const data = {};
            data['提交時間'] = new Date().toLocaleString('zh-TW');
            
            const processedKeys = new Set();
            
            for (let [key, value] of formData_obj.entries()) {
                if (processedKeys.has(key)) continue;
                
                if (key.endsWith('_select')) {
                    const baseKey = key.replace('_select', '');
                    data[baseKey] = value;
                    processedKeys.add(key);
                } else if (key.endsWith('_text')) {
                    const baseKey = key.replace('_text', '');
                    data[baseKey + '_名稱'] = value;
                    processedKeys.add(key);
                } else {
                    const checkboxes = formElement.querySelectorAll(\`[name="\${key}"]:checked\`);
                    if (checkboxes.length > 1) {
                        data[key] = Array.from(checkboxes).map(cb => cb.value).join(', ');
                    } else {
                        data[key] = value;
                    }
                }
            }
            
            sendToGoogleSheets(formData.spreadsheetId, formData.appsScriptUrl, data);
        }

        async function sendToGoogleSheets(spreadsheetId, appsScriptUrl, data) {
            if (!spreadsheetId && !appsScriptUrl) {
                showAlert('準備列印...', 'success');
                setTimeout(() => {
                    printForm();
                    setTimeout(() => {
                        document.getElementById('userForm').reset();
                    }, 3000);
                }, 500);
                return;
            }

            if (!spreadsheetId) {
                showAlert('尚未設定試算表 ID', 'error');
                return;
            }

            showAlert('提交中...', 'success');
            
            try {
                if (appsScriptUrl) {
                    const response = await fetch(appsScriptUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'text/plain' },
                        body: JSON.stringify({ 
                            spreadsheetId: spreadsheetId, 
                            rowData: data 
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showAlert('提交成功', 'success');
                        setTimeout(() => {
                            printForm();
                            setTimeout(() => {
                                document.getElementById('userForm').reset();
                            }, 3000);
                        }, 500);
                    } else {
                        showAlert('提交失敗', 'error');
                    }
                } else {
                    console.log('表單資料：', data);
                    console.log('試算表 ID：', spreadsheetId);
                    
                    setTimeout(() => {
                        showAlert('提交成功（測試模式）', 'success');
                        setTimeout(() => {
                            printForm();
                            setTimeout(() => {
                                document.getElementById('userForm').reset();
                            }, 3000);
                        }, 1000);
                    }, 1000);
                }
            } catch (error) {
                showAlert('提交失敗', 'error');
                console.error('提交錯誤：', error);
            }
        }

        function showAlert(message, type) {
            const oldToast = document.querySelector('.toast');
            if (oldToast) {
                oldToast.remove();
            }
            
            const toast = document.createElement('div');
            toast.className = 'toast' + (type === 'error' ? ' error' : '');
            toast.textContent = message;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.classList.add('show');
            }, 10);
            
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.remove();
                    }
                }, 300);
            }, 3000);
        }

        function printForm() {
            const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
            const allRadios = document.querySelectorAll('input[type="radio"]');
            
            allCheckboxes.forEach(cb => {
                if (!cb.checked) {
                    cb.parentElement.style.display = 'none';
                }
            });
            
            allRadios.forEach(rb => {
                if (!rb.checked) {
                    rb.parentElement.style.display = 'none';
                }
            });
            
            window.print();
            
            setTimeout(() => {
                allCheckboxes.forEach(cb => {
                    cb.parentElement.style.display = '';
                });
                
                allRadios.forEach(rb => {
                    rb.parentElement.style.display = '';
                });
            }, 100);
        }

        window.addEventListener('DOMContentLoaded', loadForm);
        `;
        
        template = template.replace('SCRIPT_CONTENT', `<script>${formDataScript}</script>`);
        template = template.replace(/FORM_TITLE/g, form.name);
        
        const fileName = form.name.replace(/[^\w\u4e00-\u9fa5]/g, '_') + '.html';
        
        const blob = new Blob([template], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showAlert('獨立檔案已生成', 'success');
    } catch (error) {
        console.error('生成檔案錯誤：', error);
        showAlert('生成失敗', 'error');
    }
}

window.onclick = function(event) {
    const itemModal = document.getElementById('itemModal');
    const confirmModal = document.getElementById('confirmModal');
    const signatureModal = document.getElementById('signatureModal');
    
    if (event.target === itemModal) {
        closeModal();
    }
    
    if (event.target === confirmModal) {
        closeConfirmModal();
    }
    
    if (event.target === signatureModal) {
        closeSignatureModal();
    }
}
